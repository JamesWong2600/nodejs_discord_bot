const { database }= require('./database');

function setMultipleSetting(options, value) {
    return new Promise((resolve, reject) => {

    });
}

module.exports = { setMultipleSetting };